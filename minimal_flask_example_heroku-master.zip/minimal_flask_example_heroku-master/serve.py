def useless_function():
    """ 
    A function that returns some text
    """
    return("some text")
